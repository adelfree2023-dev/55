import { SetMetadata } from '@nestjs/common';

export const SKIP_TENANT_VALIDATION = 'skipTenantValidation';
export const SkipTenantValidation = () => SetMetadata(SKIP_TENANT_VALIDATION, true);
