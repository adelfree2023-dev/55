import { describe, it, expect, mock, beforeEach } from 'bun:test';
import { RedisService } from './redis.service';

describe('RedisService', () => {
    let service: RedisService;
    let mockClient: any;
    let loggedErrors: string[] = [];
    let loggedWarns: string[] = [];

    beforeEach(() => {
        loggedErrors = [];
        loggedWarns = [];
        mockClient = {
            connect: mock(() => Promise.resolve()),
            quit: mock(() => Promise.resolve()),
            get: mock(() => Promise.resolve('value')),
            set: mock(() => Promise.resolve()),
            setEx: mock(() => Promise.resolve()),
            del: mock(() => Promise.resolve(1)),
            incr: mock(() => Promise.resolve(1)),
            expire: mock(() => Promise.resolve(true)),
            keys: mock(() => Promise.resolve(['key1', 'key2'])),
            flushDb: mock(() => Promise.resolve()),
            ping: mock(() => Promise.resolve('PONG')),
            on: mock((event: string, callback: Function) => {
                if (event === 'error') {
                    (mockClient as any).errorHandler = callback;
                }
                if (event === 'reconnecting') {
                    (mockClient as any).reconnectHandler = callback;
                }
            }),
            options: {
                socket: {
                    reconnectStrategy: (retries: number) => {
                        if (retries > 10) return false;
                        return retries * 50;
                    }
                }
            }
        };

        service = new RedisService();
        (service as any).client = mockClient;

        (service as any).logger = {
            error: mock((msg: string) => loggedErrors.push(msg)),
            warn: mock((msg: string) => loggedWarns.push(msg)),
            log: mock(() => { }),
        };
    });

    it('should connect on module init', async () => {
        await service.onModuleInit();
        expect(mockClient.connect).toHaveBeenCalled();
        expect((service as any).isConnected).toBe(true);
    });

    it('should handle connection failure', async () => {
        mockClient.connect = mock(() => Promise.reject(new Error('Conn fail')));
        await expect(service.onModuleInit()).rejects.toThrow('Conn fail');
        expect(loggedErrors.some(m => m.includes('Failed to connect to Redis: Conn fail'))).toBe(true);
    });

    it('should close connection on destroy if connected', async () => {
        (service as any).isConnected = true;
        await service.onModuleDestroy();
        expect(mockClient.quit).toHaveBeenCalled();
    });

    it('should skip quit if not connected', async () => {
        (service as any).isConnected = false;
        await service.onModuleDestroy();
        // quit should not be called
    });

    it('should throw error if getClient called when not connected', () => {
        (service as any).isConnected = false;
        expect(() => service.getClient()).toThrow('Redis not connected');
    });

    it('should return client if connected', () => {
        (service as any).isConnected = true;
        const client = service.getClient();
        expect(client).toBeDefined();
    });

    it('should handle redis errors via event listener', () => {
        const error = new Error('Connection failed');
        const errorHandler = (mockClient as any).errorHandler;
        if (errorHandler) {
            errorHandler(error);
            expect(loggedErrors.some(m => m.includes('Redis error: Connection failed'))).toBe(true);
        }
    });

    it('should handle reconnecting events', () => {
        const reconnectHandler = (mockClient as any).reconnectHandler;
        if (reconnectHandler) {
            reconnectHandler();
            expect(loggedWarns.some(m => m.includes('Redis reconnecting...'))).toBe(true);
        }
    });

    it('should handle reconnect strategy', () => {
        const strat = mockClient.options.socket.reconnectStrategy;
        expect(strat(1)).toBe(50);
        expect(strat(5)).toBe(250);
        expect(strat(11)).toBe(false);
    });

    it('should cover all operational methods', async () => {
        (service as any).isConnected = true;
        await service.get('key');
        await service.set('key', 'val');
        await service.set('key', 'val', 10);
        await service.del('key');
        await service.incr('key');
        await service.expire('key', 10);
        await service.keys('*');
        await service.flushDb();
        await service.ping();

        expect(mockClient.get).toHaveBeenCalled();
        expect(mockClient.set).toHaveBeenCalled();
        expect(mockClient.setEx).toHaveBeenCalled();
        expect(mockClient.del).toHaveBeenCalled();
        expect(mockClient.incr).toHaveBeenCalled();
        expect(mockClient.expire).toHaveBeenCalled();
        expect(mockClient.keys).toHaveBeenCalled();
        expect(mockClient.flushDb).toHaveBeenCalled();
        expect(mockClient.ping).toHaveBeenCalled();
    });

    it('should test constructor initialization', () => {
        const newService = new RedisService();
        expect(newService).toBeDefined();
        expect((newService as any).client).toBeDefined();
    });
});
