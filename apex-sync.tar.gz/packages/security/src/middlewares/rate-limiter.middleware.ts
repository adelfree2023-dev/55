import { Injectable, NestMiddleware, Logger, HttpException, HttpStatus } from '@nestjs/common';
import { createClient } from 'redis';

@Injectable()
export class RateLimiterMiddleware implements NestMiddleware {
    private readonly logger = new Logger(RateLimiterMiddleware.name);
    private static client = createClient({ url: process.env.REDIS_URL });
    private static isConnected = false;

    async use(req: any, res: any, next: () => void) {
        try {
            if (!RateLimiterMiddleware.isConnected) {
                // Ensure client is created with current env var
                if (!RateLimiterMiddleware.client) {
                    RateLimiterMiddleware.client = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
                }
                await RateLimiterMiddleware.client.connect();
                RateLimiterMiddleware.isConnected = true;
            }

            const tenantId = req.tenantId || 'anonymous';
            const tier = req.tenantTier || 'basic';

            const limits: Record<string, number> = { basic: 100, pro: 1000, enterprise: 10000 };
            const limit = limits[tier] || limits.basic;

            // Fastify uses .url or .routerPath, not .path
            const path = req.path || req.url || req.routerPath || 'unknown';
            const key = `rate_limit:${tenantId}:${req.ip}:${path}`;

            this.logger.log(`🚦 Rate limit check: ${key} (Tier: ${tier}, Limit: ${limit})`);
            console.log(`[RATE_LIMIT_DEBUG] Key: ${key}, Tier: ${tier}, Limit: ${limit}`);

            const current = await RateLimiterMiddleware.client.incr(key);

            this.logger.log(`📊 Current count for ${key}: ${current}/${limit}`);
            console.log(`[RATE_LIMIT_DEBUG] Current: ${current}/${limit}`);

            if (current === 1) {
                await RateLimiterMiddleware.client.expire(key, 60);
            }

            // Set headers
            const setHeader = (name: string, value: string) => {
                if (typeof res.setHeader === 'function') res.setHeader(name, value);
                else if (typeof res.header === 'function') res.header(name, value);
            };

            setHeader('X-RateLimit-Limit', limit.toString());
            setHeader('X-RateLimit-Remaining', Math.max(0, limit - current).toString());

            if (current > limit) {
                this.logger.warn(`Rate limit exceeded for ${tenantId} (${req.ip}) on ${path}`);

                throw new HttpException({
                    statusCode: 429,
                    error: 'Too Many Requests',
                    message: 'Rate limit exceeded. Please try again later.'
                }, 429);
            }

            next();
        } catch (error) {
            if (error instanceof HttpException) {
                throw error;
            }
            this.logger.error(`Rate limiter error: ${error}`);
            // In case of Redis failure, we fail open but log loudly. 
            // For Phase 1 remediation, we should consider if we want to fail closed.
            return next();
        }
    }
}
