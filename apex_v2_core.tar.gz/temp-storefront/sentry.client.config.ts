// This file configures the initialization of Sentry on the client (browser).
import * as Sentry from "@sentry/nextjs";

Sentry.init({
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN || "https://8142937fd486d889e5f8ec0113b4faa2@o4510677183168512.ingest.us.sentry.io/4510801156571136",

    // Adjust this value in production, or use tracesSampleRate for greater control
    tracesSampleRate: 0.1,

    // Setting this option to true will print useful information to the console while you're setting up Sentry.
    debug: false,

    environment: process.env.NODE_ENV || 'production',

    release: process.env.SENTRY_RELEASE || 'apex-platform@1.0.0',
});
