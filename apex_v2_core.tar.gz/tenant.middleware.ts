import { Injectable, NestMiddleware, ForbiddenException, Logger, BadRequestException } from '@nestjs/common';
import { FastifyRequest, FastifyReply } from 'fastify';
import { setSchemaPath } from '@apex/db';
import * as pg from 'pg';

@Injectable()
export class TenantMiddleware implements NestMiddleware {
    private readonly logger = new Logger(TenantMiddleware.name);
    private readonly pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

    private extractSubdomain(host: string): string | null {
        if (!host) return null;

        // Handle apex.localhost AND apex-v2.duckdns.org patterns
        const apexPatterns = [
            /^([a-z0-9-]+)\.apex\.localhost$/,
            /^([a-z0-9-]+)\.apex-v2\.duckdns\.org$/,
            /^([a-z0-9-]+)\.localhost$/
        ];

        for (const pattern of apexPatterns) {
            const match = host.match(pattern);
            if (match) return match[1];
        }
        return null;
    }

    async use(req: FastifyRequest['raw'], res: FastifyReply['raw'], next: () => void) {
        // Safe extraction from multiple sources
        const host = (req.headers['x-forwarded-host'] || req.headers['host']) as string;
        let subdomain = this.extractSubdomain(host);

        // Fallback or override from header (still subject to validation)
        const headerTenant = req.headers['x-tenant-id'] as string;
        if (headerTenant) {
            subdomain = headerTenant;
        }

        // Ignore infrastructure subdomains
        if (!subdomain || ['api', 'www', 'localhost', 'apex-v2', 'provisioning'].includes(subdomain.toLowerCase())) {
            this.logger.debug(`No tenant context for host: ${host}`);
            // Provisioning routes are excluded in AppModule, but we check here too for safety
            return next();
        }

        // 🔴 CRITICAL FIX: VALIDATE AGAINST WHITELIST BEFORE SCHEMA ACCESS
        // Using strict regex validation and status check
        const SUBDOMAIN_REGEX = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/;
        if (!SUBDOMAIN_REGEX.test(subdomain)) {
            this.logger.warn(`🚨 BLOCKED MALFORMED SUBDOMAIN ATTEMPT: ${subdomain} from ${req.socket.remoteAddress}`);
            throw new ForbiddenException('Invalid tenant context');
        }

        try {
            // Resolve subdomain to tenant ID using direct pool with ACTIVE status check
            const result = await this.pool.query(
                `SELECT id FROM public.tenants 
                 WHERE subdomain = $1 
                 AND status = 'active'`,
                [subdomain]
            );

            if (result.rows.length === 0) {
                this.logger.warn(`🚨 BLOCKED INVALID/INACTIVE TENANT ACCESS: ${subdomain} from ${req.socket.remoteAddress}`);
                // 403 Forbidden instead of 404 to avoid tenant enumeration
                throw new ForbiddenException('Invalid tenant context');
            }

            const tenantId = result.rows[0].id;
            (req as any).tenantId = tenantId;

            // Set the database search path for the current request context
            await setSchemaPath(tenantId);
            this.logger.debug(`Resolved tenant ${subdomain} to ID ${tenantId}`);
            next();
        } catch (error) {
            if (error instanceof ForbiddenException) throw error;
            this.logger.error(`Tenant resolution failed for ${subdomain}: ${error.message}`, error.stack);
            throw new ForbiddenException('Tenant context resolution failed');
        }
    }
}
