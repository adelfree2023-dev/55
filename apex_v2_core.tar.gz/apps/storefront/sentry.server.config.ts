// This file configures the initialization of Sentry on the server.
import * as Sentry from "@sentry/nextjs";

Sentry.init({
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
    enabled: !!process.env.NEXT_PUBLIC_SENTRY_DSN,

    tracesSampleRate: 0.1,
    debug: false,
    environment: process.env.NODE_ENV || 'production',
    release: process.env.SENTRY_RELEASE || 'apex-platform@1.0.0',
});
