export declare class HealthController {
    check(): {
        status: string;
        timestamp: string;
    };
}
