import { NestMiddleware } from '@nestjs/common';
import { FastifyRequest, FastifyReply } from 'fastify';
export declare class TenantMiddleware implements NestMiddleware {
    private readonly logger;
    private readonly pool;
    private extractSubdomain;
    use(req: FastifyRequest['raw'], res: FastifyReply['raw'], next: () => void): Promise<void>;
}
