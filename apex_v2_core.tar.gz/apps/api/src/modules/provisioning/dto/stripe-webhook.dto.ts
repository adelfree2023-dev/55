import { StripeWebhookData as IStripeWebhookData } from '@apex/validators';

export type StripeWebhookDto = IStripeWebhookData;
