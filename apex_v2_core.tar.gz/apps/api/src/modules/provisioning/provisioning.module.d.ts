export declare class ProvisioningModule {
}
