export declare class TenantFailedEvent {
    readonly payload: {
        subdomain: string;
        error: string;
        duration: number;
    };
    constructor(payload: {
        subdomain: string;
        error: string;
        duration: number;
    });
}
