import { CreateTenantDto } from './dto/create-tenant.dto';
import { ProvisioningService } from './provisioning.service';
export declare class ProvisioningController {
    private readonly provisioningService;
    private readonly logger;
    constructor(provisioningService: ProvisioningService);
    createTenant(dto: CreateTenantDto): Promise<{
        success: boolean;
        subdomain: CreateTenantDto;
        schemaName: string;
        duration: number;
        phases: {
            schema: number;
            seed: number;
            route: number;
            register: number;
        };
        northStar: string;
    }>;
    handleStripeWebhook(payload: any, signature: string): Promise<{
        received: boolean;
    }>;
}
