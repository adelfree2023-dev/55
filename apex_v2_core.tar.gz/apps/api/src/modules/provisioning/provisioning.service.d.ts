import { Pool } from 'pg';
import { SchemaCreatorService, DataSeederService, TraefikRouterService } from '@apex/provisioning';
import { CreateTenantDto } from '../../dto/create-tenant.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EncryptionService } from '@apex/encryption';
export declare class ProvisioningService {
    private readonly schemaCreator;
    private readonly dataSeeder;
    private readonly traefikRouter;
    private readonly eventEmitter;
    private readonly encryptionService;
    private readonly pool;
    private readonly logger;
    constructor(schemaCreator: SchemaCreatorService, dataSeeder: DataSeederService, traefikRouter: TraefikRouterService, eventEmitter: EventEmitter2, encryptionService: EncryptionService, pool?: Pool);
    provisionTenant(dto: CreateTenantDto): Promise<{
        success: boolean;
        subdomain: CreateTenantDto;
        schemaName: string;
        duration: number;
        phases: {
            schema: number;
            seed: number;
            route: number;
            register: number;
        };
        northStar: string;
    }>;
    private registerTenant;
    validateSubdomain(subdomain: string): Promise<boolean>;
}
