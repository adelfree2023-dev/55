export declare class StorefrontModule {
}
