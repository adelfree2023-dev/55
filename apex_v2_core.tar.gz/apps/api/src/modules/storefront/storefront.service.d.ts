import { CacheService } from '@apex/cache';
export declare class StorefrontService {
    private readonly cacheService;
    private readonly logger;
    private readonly pool;
    constructor(cacheService: CacheService);
    getHomePage(tenantId: string): Promise<any>;
    private getHeroBanners;
    private getBestSellers;
    private getFeaturedCategories;
    private getPromotions;
    private getTestimonials;
    invalidateCache(tenantId: string): Promise<void>;
    warmCache(tenantId: string): Promise<void>;
}
