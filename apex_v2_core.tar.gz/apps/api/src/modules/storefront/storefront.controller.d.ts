import { StorefrontService } from './storefront.service';
export declare class StorefrontController {
    private readonly storefrontService;
    private readonly logger;
    constructor(storefrontService: StorefrontService);
    getHomePage(tenantId: string): Promise<any>;
    refreshHomePage(tenantId: string): Promise<{
        success: boolean;
        message: string;
        timestamp: string;
    }>;
}
