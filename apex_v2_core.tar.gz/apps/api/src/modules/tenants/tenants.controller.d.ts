import { TenantQuery } from './schemas/tenant-query.schema';
import { TenantsService } from './tenants.service';
export declare class TenantsController {
    private readonly tenantsService;
    private readonly logger;
    constructor(tenantsService: TenantsService);
    findAll(query: TenantQuery): Promise<{
        data: any[];
        pagination: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    findOne(id: string): Promise<any>;
}
