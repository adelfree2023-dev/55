export declare class TenantsModule {
}
