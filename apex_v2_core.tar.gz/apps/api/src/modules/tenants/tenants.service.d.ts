import { TenantQuery } from './schemas/tenant-query.schema';
export declare class TenantsService {
    private readonly logger;
    private readonly pool;
    constructor();
    findAll(query: TenantQuery): Promise<{
        data: any[];
        pagination: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    findOne(id: string): Promise<any>;
}
