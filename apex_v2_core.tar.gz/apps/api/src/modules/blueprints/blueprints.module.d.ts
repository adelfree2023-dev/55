export declare class BlueprintsModule {
}
