import { CreateBlueprintDto, UpdateBlueprintDto } from './dto';
export declare class BlueprintsService {
    private readonly logger;
    private readonly pool;
    constructor();
    findAll(): Promise<any[]>;
    findOne(id: string): Promise<any>;
    create(createDto: CreateBlueprintDto): Promise<any>;
    update(id: string, updateDto: UpdateBlueprintDto): Promise<any>;
    remove(id: string): Promise<{
        success: boolean;
        id: string;
    }>;
}
