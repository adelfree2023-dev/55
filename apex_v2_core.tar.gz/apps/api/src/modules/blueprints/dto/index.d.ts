import { z } from 'zod';
export declare const CreateBlueprintDto: z.ZodObject<{
    name: z.ZodString;
    config: z.ZodObject<{
        steps: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            required: z.ZodDefault<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }, {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }>, "many">;
        welcome_message: z.ZodOptional<z.ZodString>;
        completion_message: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    }, {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    }>;
    is_default: z.ZodDefault<z.ZodBoolean>;
}, "strict", z.ZodTypeAny, {
    name?: string;
    config?: {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    };
    is_default?: boolean;
}, {
    name?: string;
    config?: {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    };
    is_default?: boolean;
}>;
export declare const UpdateBlueprintDto: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    config: z.ZodOptional<z.ZodObject<{
        steps: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            title: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            required: z.ZodDefault<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }, {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }>, "many">;
        welcome_message: z.ZodOptional<z.ZodString>;
        completion_message: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    }, {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    }>>;
    is_default: z.ZodOptional<z.ZodDefault<z.ZodBoolean>>;
}, "strict", z.ZodTypeAny, {
    name?: string;
    config?: {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    };
    is_default?: boolean;
}, {
    name?: string;
    config?: {
        steps?: {
            id?: string;
            description?: string;
            required?: boolean;
            title?: string;
        }[];
        welcome_message?: string;
        completion_message?: string;
    };
    is_default?: boolean;
}>;
export type CreateBlueprintDto = z.infer<typeof CreateBlueprintDto>;
export type UpdateBlueprintDto = z.infer<typeof UpdateBlueprintDto>;
