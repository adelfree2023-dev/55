import { CreateBlueprintDto, UpdateBlueprintDto } from './dto';
import { BlueprintsService } from './blueprints.service';
export declare class BlueprintsController {
    private readonly blueprintsService;
    private readonly logger;
    constructor(blueprintsService: BlueprintsService);
    findAll(): Promise<any[]>;
    findOne(id: string): Promise<any>;
    create(createDto: CreateBlueprintDto): Promise<any>;
    update(id: string, updateDto: UpdateBlueprintDto): Promise<any>;
    remove(id: string): Promise<{
        success: boolean;
        id: string;
    }>;
}
