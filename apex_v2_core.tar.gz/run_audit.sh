#!/bin/bash
cd ~/apex-v2
export PATH=/home/apex-v2-dev/.bun/bin:$PATH
export API_URL=http://localhost:4000
pkill -f bun || true
redis-cli flushall
sleep 2
nohup /home/apex-v2-dev/.bun/bin/bun run apps/api/src/main.ts > api_audit_final.log 2>&1 &
echo "Started API, waiting for health..."
for i in {1..30}; do
  if curl -s http://localhost:4000/health?skip_tenant_validation=1 | grep -q 'ok'; then
    echo "API IS UP"
    break
  fi
  sleep 2
done
echo "Running penetration tests..."
# Run isolation tests first, then rate limiting, then others
# OR just add a delay between tests in the script.
# Let's just run it normally but ensure we don't have artifacts.
/home/apex-v2-dev/.bun/bin/bun run scripts/penetration-test.ts > penetration_final.log 2>&1
echo "DONE"
