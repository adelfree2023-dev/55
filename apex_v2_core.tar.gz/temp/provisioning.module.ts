import { Module } from '@nestjs/common';
import { Pool } from 'pg';
import { db } from '@apex/db';

@Module({
    imports: [EncryptionModule],
    controllers: [ProvisioningController],
    providers: [
        {
            provide: 'PROVISIONING_SERVICE',
            useClass: ProvisioningService,
        },
        {
            provide: 'SCHEMA_CREATOR_SERVICE',
            useClass: SchemaCreatorService,
        },
        {
            provide: 'DATA_SEEDER_SERVICE',
            useClass: DataSeederService,
        },
        {
            provide: 'TRAEFIK_ROUTER_SERVICE',
            useClass: TraefikRouterService,
        },
        {
            provide: 'BoundPool',
            useValue: new Pool({ connectionString: process.env.DATABASE_URL }),
        },
        {
            provide: 'DATABASE_CONNECTION',
            useValue: db,
        },
        ProvisioningService,
        SchemaCreatorService,
        DataSeederService,
        TraefikRouterService,
    ],
    exports: ['PROVISIONING_SERVICE', 'SCHEMA_CREATOR_SERVICE', 'DATA_SEEDER_SERVICE', 'TRAEFIK_ROUTER_SERVICE', ProvisioningService],
})
export class ProvisioningModule { }
