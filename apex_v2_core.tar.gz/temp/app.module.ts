import { Module, NestModule, MiddlewareConsumer, RequestMethod } from '@nestjs/common';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { AuditLoggerInterceptor, RateLimiterMiddleware, HelmetMiddleware } from '@apex/security';
import { TenantMiddleware } from './common/middleware/tenant.middleware';
import { ProvisioningModule } from './modules/provisioning/provisioning.module';
import { StorefrontModule } from './modules/storefront/storefront.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { HealthController } from './common/controllers/health.controller';

@Module({
    imports: [
        EventEmitterModule.forRoot(),
        ProvisioningModule,
        StorefrontModule,
    ],
    controllers: [HealthController],
    providers: [
        {
            provide: APP_INTERCEPTOR,
            useClass: AuditLoggerInterceptor,
        },
    ],
})
export class AppModule implements NestModule {
    configure(consumer: MiddlewareConsumer) {
        // Apply HelmetMiddleware for global security headers (CSP, HSTS, etc.)
        consumer
            .apply(HelmetMiddleware)
            .forRoutes({ path: '*', method: RequestMethod.ALL });

        // Apply TenantMiddleware first to set tenantId and tier
        consumer
            .apply(TenantMiddleware)
            .exclude('provisioning/(.*)')
            .forRoutes({ path: '*', method: RequestMethod.ALL });

        // Apply RateLimiterMiddleware after tenant context is set
        consumer
            .apply(RateLimiterMiddleware)
            .forRoutes({ path: '*', method: RequestMethod.ALL });
    }
}
