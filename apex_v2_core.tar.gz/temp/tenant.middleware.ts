import { Injectable, NestMiddleware, BadRequestException, ForbiddenException, Logger } from '@nestjs/common';
import { FastifyRequest, FastifyReply } from 'fastify';
import { Pool } from 'pg';
import { setSchemaPath } from '@apex/db';

@Injectable()
export class TenantMiddleware implements NestMiddleware {
    private readonly logger = new Logger(TenantMiddleware.name);
    // Use a pool initialized with connection string for middleware access
    private readonly pool = new Pool({ connectionString: process.env.DATABASE_URL });
    private readonly whitelistCache = new Map<string, boolean>();

    async use(req: any, res: any, next: () => void) {
        try {
            // 1. Extract tenant from HOST header (NOT X-Tenant-Id)
            const host = req.headers['x-forwarded-host'] || req.headers['host'];

            if (!host) {
                // Fallback for health checks or direct IP access?
                // Audit implies strictness. 
                throw new BadRequestException('Host header is missing');
            }

            const tenantId = this.extractSubdomain(Array.isArray(host) ? host[0] : host);

            if (!tenantId) {
                // If we can't extract a subdomain, it might be a request to the root domain or invalid
                // We should probably block transparency or allow public routes (AppModule handles strictness usually)
                // The audit says "Invalid tenant context" -> 403.
                // But for root domain (e.g. www.apex.com) maybe it's allowed?
                // Let's assume strict tenant context is required for routes guarded by this middleware.
                // However, blocking 'localhost:3000' might break dev.
                // I will add a dev bypass for localhost triggers if needed, but the audit was strict.
                // I will return 403 if no subdomain found.
                this.logger.warn(`No tenant subdomain found in host: ${host}`);
                // Allow passing through if it's not a tenant route? 
                // The middleware is global. If I throw here, I block everything.
                // Existing code had: if (!subdomain) next(). 
                // Audit says: "You've built a multi-tenant vault... that accepts ANY tenant ID... ONE missing validation check".
                // So if I identify a tenant, I MUST validate it.
                // If I don't identify a tenant, do I block?
                // "Attacker can ACCESS ANY EXISTING TENANT by guessing subdomain"
                // "Attacker can CREATE NEW TENANT SCHEMAS"
                // The fix is: Verify against whitelist.

                // If no subdomain, we probably shouldn't set a schema path or tenantId.
                // Let's assume we pass next() but don't set tenantId.
                return next();
            }

            // 2. Validate against whitelist (with cache)
            if (!await this.isWhitelisted(tenantId)) {
                this.logger.warn(`🚨 BLOCKED INVALID TENANT ACCESS: ${tenantId} from ${req.ip}`);
                throw new ForbiddenException('Invalid tenant context');
            }

            // 3. Set schema AFTER validation
            await setSchemaPath(`tenant_${tenantId}`);

            // Attach tenantId to request for downstream use
            req.tenantId = tenantId;

            next();
        } catch (error) {
            if (error instanceof ForbiddenException || error instanceof BadRequestException) {
                throw error;
            }
            this.logger.error(`Tenant resolution error: ${error.message}`, error.stack);
            throw new ForbiddenException('Tenant context resolution failed');
        }
    }

    private extractSubdomain(host: string): string | null {
        const cleanHost = host.split(':')[0];
        // Match apex.localhost, apex-v2.duckdns.org patterns or standard subdomains
        const match = cleanHost.match(/^(?:www\.)?([a-z0-9-]+)\.(?:apex\.localhost|apex-v2\.duckdns\.org|localhost)$/);

        if (match) {
            return match[1];
        }

        // Handle direct localhost for dev/testing if needed (or fail)
        // If host is just "localhost", match is null.
        return null;
    }

    private async isWhitelisted(tenantId: string): Promise<boolean> {
        // Cache validation for 5 minutes
        if (this.whitelistCache.has(tenantId)) {
            return this.whitelistCache.get(tenantId)!;
        }

        try {
            // Validate format first
            if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(tenantId)) {
                return false;
            }

            const result = await this.pool.query(
                `SELECT 1 FROM public.tenants WHERE subdomain = $1 AND status = 'active'`,
                [tenantId]
            );

            const isWhitelisted = result.rows.length > 0;
            this.whitelistCache.set(tenantId, isWhitelisted);

            setTimeout(() => this.whitelistCache.delete(tenantId), 300000);
            return isWhitelisted;
        } catch (error) {
            this.logger.error(`Whitelist check failed: ${error.message}`);
            return false;
        }
    }
}
