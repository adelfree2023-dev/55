import { Injectable, NestMiddleware } from '@nestjs/common';
import { createClient } from 'redis';

@Injectable()
export class RateLimiterMiddleware implements NestMiddleware {
    // Client should be managed properly, ideally injected or initialized once
    private static client = createClient({ url: process.env.REDIS_URL });

    async use(req: any, res: any, next: () => void) {
        if (!RateLimiterMiddleware.client.isOpen) {
            await RateLimiterMiddleware.client.connect();
        }

        const tenantId = (req as any).tenantId || 'anonymous';
        const tier = (req as any).tenantTier || 'basic';

        const limits: Record<string, number> = { basic: 100, pro: 1000, enterprise: 10000 };
        const limit = limits[tier] || limits.basic;
        // Construct the key accurately
        const key = `rate_limit:${tenantId}:${req.ip}:${req.path}`;

        // logic to check redis
        const current = await RateLimiterMiddleware.client.incr(key);

        if (current === 1) {
            await RateLimiterMiddleware.client.expire(key, 60);
        }

        // Set headers
        if (res.setHeader) {
            res.setHeader('X-RateLimit-Limit', limit.toString());
            res.setHeader('X-RateLimit-Remaining', Math.max(0, limit - current).toString());
        } else if (res.header) {
            res.header('X-RateLimit-Limit', limit.toString());
            res.header('X-RateLimit-Remaining', Math.max(0, limit - current).toString());
        }

        if (current > limit) {
            if (res.status) {
                return res.status(429).json({ error: 'Too many requests' });
            } else {
                // Fallback for non-express response objects if necessary, though unlikely with NestMiddleware types
                return (res as any).code(429).send({ error: 'Too many requests' });
            }
        }

        next();
    }
}
